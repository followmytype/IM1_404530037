import java.util.Scanner;

public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Easter Year = new Easter();
	Scanner scanner = new Scanner(System.in);
		System.out.println(Year.getEaster(2001));
		System.out.println(Year.getEaster(2012));
	System.out.print("Enter the year:");
	System.out.println(Year.getEaster(scanner.nextInt()));
	}

}
