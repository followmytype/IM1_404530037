package finalproject;

import java.awt.EventQueue;
import java.awt.Label;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConvertMoney {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConvertMoney window = new ConvertMoney();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ConvertMoney() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("");//���G
		lblNewLabel.setBounds(251, 37, 57, 19);
		frame.getContentPane().add(lblNewLabel);
		
		String[] option=new String[]{"EUR","USD","GBP"};//��ܿ�J�f�����
		JComboBox comboBox = new JComboBox(option);
		comboBox.setBounds(144, 34, 58, 25);
		frame.getContentPane().add(comboBox);
		String select=(String) comboBox.getSelectedItem();
	
		
		
		
	
		textField = new JTextField();//��J�ƶq
		textField.setBounds(14, 34, 116, 25);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("=");
		label.setBounds(216, 37, 57, 19);
		frame.getContentPane().add(label);
		
		
		JComboBox comboBox_1 = new JComboBox(option);//��ܿ�X�f�����
		comboBox_1.setBounds(344, 34, 53, 25);
		frame.getContentPane().add(comboBox_1);
		
		JButton button = new JButton("\u8A08\u7B97");//�p��
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String convert=(String) comboBox.getSelectedItem();
				String result=(String) comboBox_1.getSelectedItem();
								
				try
				{ 
			    double amount=Double.parseDouble(textField.getText());
				if(!convert.equals(result)&&amount>=0){												
					if(convert.equals("EUR")&&result.equals("USD")){amount*=1.42; lblNewLabel.setText(String.valueOf(amount));}
					else if(convert.equals("USD")&&result.equals("EUR")){amount/=1.42; lblNewLabel.setText(String.valueOf(amount));}
					
					else if(convert.equals("GBP")&&result.equals("USD")){amount*=1.64; lblNewLabel.setText(String.valueOf(amount));}
					else if(convert.equals("USD")&&result.equals("GBP")){amount/=1.64; lblNewLabel.setText(String.valueOf(amount));}
					
					else if(convert.equals("GBP")&&result.equals("EUR")){amount*=1.13; lblNewLabel.setText(String.valueOf(amount));}
					else if(convert.equals("EUR")&&result.equals("GBP")){amount/=1.13; lblNewLabel.setText(String.valueOf(amount));}										   									   								    				
				                           }
				else {System.out.println("Please check your input or option");}
			    }
				catch(Exception e){System.out.println("Please input the correct format");}
			
		}});
		
		button.setBounds(160, 190, 99, 27);
		frame.getContentPane().add(button);
	}
}
